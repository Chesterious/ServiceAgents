from typing import Callable

from langchain.agents import AgentState
from langchain.agents.middleware import before_model, dynamic_prompt,  ModelRequest, wrap_tool_call
from langchain_core.messages import ToolMessage
from langgraph.prebuilt.tool_node import ToolCallRequest
from langgraph.runtime import Runtime
from langgraph.types import Command

from utils.logger_handler import logger
from utils.prompt_loader import load_report_prompt, load_system_prompt


@wrap_tool_call
def monitor_tool(
        # 请求的数据封装
        request: ToolCallRequest,
        # 执行函数本身
        handler: Callable[[ToolCallRequest], ToolMessage | Command]
) -> ToolMessage | Command:                   # 工具执行监控
    logger.info(f'[工具调用]: {request.tool_call["name"]}')
    logger.info(f'[工具参数]: {request.tool_call["args"]}')

    try:
        result = handler(request)
        logger.info(f'[工具调用]: {request.tool_call["name"]}调用成功')
        if request.tool_call["name"] == "fill_context_for_report":
            request.runtime.context["report"] = True

        return result
    except Exception as e:
        logger.error(f'[工具调用异常]: {request.tool_call["name"]}调用失败，原因{str(e)}')
        raise e


@before_model
def log_before_model(
        state: AgentState,          # 整个Agent智能体中的状态记录
        runtime: Runtime            # 记录整个执行过程的上下文信息
):               # 模型执行前日志
    logger.info(f"[模型即将被调用]:带有{len(state['messages'])}条消息")

    logger.debug(f"[模型即将被调用]: {type(state['messages'][-1]).__name__} | {state['messages'][-1].content.strip()}")

    return None


@dynamic_prompt                       # 每次在生成提示词前执行
def report_prompt_switch(request: ModelRequest):           # 动态切换提示次
    is_report = request.runtime.context.get("report", False)
    if is_report:
        return load_report_prompt()
    return load_system_prompt()