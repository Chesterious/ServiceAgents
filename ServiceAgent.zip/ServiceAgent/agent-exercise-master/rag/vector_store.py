import os

from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

from model.factory import embed_model
from utils.config_handler import chroma_conf
from utils.file_handler import listdir_with_allowed_type, get_file_md5_hex, txt_loader, pdf_loader, docx_loader
from utils.logger_handler import logger
from utils.path_tool import get_abs_path # 这也是我们之前封装好的工具函数，用来获取绝对路径


class VectorStoreService:
    def __init__(self):
        self.vector_store = Chroma(
            collection_name=chroma_conf["collection_name"],
            embedding_function=embed_model,
            persist_directory=chroma_conf["persist_directory"]
        )

        self.spliter = RecursiveCharacterTextSplitter(
            chunk_size=chroma_conf["chunk_size"],
            chunk_overlap=chroma_conf["chunk_overlap"],
            separators=chroma_conf["separators"],
            length_function=len
        )

    def get_retriever(self):
        return self.vector_store.as_retriever(search_kwargs={"k": chroma_conf["k"]}) # chroma_conf是之前config_handler准备好的变量
        # 其中k是指返回的向量数量，可以根据需要调整

    def load_documents(self):
        """
        从数据文件夹内读取数据文件，转为向量存入向量库
        要计算文件md5去重
        :return: None
        """

        def _check_md5_hex(md5_for_check: str):
            if not os.path.exists(get_abs_path(chroma_conf["md5_hex_store"])):
                # 创建文件
                open(get_abs_path(chroma_conf["md5_hex_store"]), "w", encoding="utf-8").close()

                return False
            with open(get_abs_path(chroma_conf["md5_hex_store"]), "r", encoding="utf-8") as f:
                for line in f.readlines():
                    if line.strip() == md5_for_check:  # strip()去掉字符串两端的空白字符和换行符
                        return True

                return False

        def _save_md5_hex(md5_for_save: str):
            with open(get_abs_path(chroma_conf["md5_hex_store"]), "a", encoding="utf-8") as f:
                f.write(md5_for_save + "\n")

        def _get_file_documents(filepath: str):
            if filepath.endswith(".pdf"):
                return pdf_loader(filepath)  # 直接使用封装好的pdf_loader函数
            elif filepath.endswith(".txt"):
                return txt_loader(filepath)
            elif filepath.endswith(".docx"):
                return docx_loader(filepath)
            else:
                logger.error(f'[文件处理]不支持的文件类型{filepath}')

                return []

        allowed_files_path = listdir_with_allowed_type(  # 这里就用上了前面，file_handler.py封装好的函数，用来获取txt和pdf文件的路径
            get_abs_path(chroma_conf["data_path"]),
            tuple(chroma_conf["allow_knowledge_file_type"])
        )

        for path in allowed_files_path:  # 下面要做的就是遍历这些文件路径，逐个读取文件内容，没重复的就转为向量存入向量库 并生成md5来防止重复。
            md5_hex = get_file_md5_hex(path)

            if _check_md5_hex(md5_hex):
                logger.info(f"[加载知识库]{path}内容已存在，跳过！")
                continue

            try:
                documents: list[Document] = _get_file_documents(path)

                if not documents:
                    logger.warning(f"[加载知识库]{path}内容为空，跳过！")
                    continue

                split_document: list[Document] = self.spliter.split_documents(documents)
                if not split_document:
                    logger.warning(f"[加载知识库]{path}分片后无有效内容，跳过！")
                    continue

                # 向量库添加数据
                self.vector_store.add_documents(split_document)

                # 保存文件md5，以防重复
                _save_md5_hex(md5_hex)

                logger.info(f"[加载知识库]{path}内容加载成功！")

            except Exception as e:
                # exc_info= True,记录详细报错信息;False仅记录报错信息
                logger.error(f"[加载知识库]{path}内容加载失败！{str(e)}", exc_info=True)
                continue


# if __name__ == '__main__':
#     vs = VectorStoreService()
#     vs.load_documents()
#
#     retriever = vs.get_retriever()
#
#     res = retriever.invoke("发展里程")
#     for r in res:
#         print(r.page_content)
#         print('-'*20)